create definer = botanico@localhost trigger trg_arbol_origen_insert
    before insert
    on arbol
    for each row
BEGIN
    IF NEW.arbol_origen_id IS NOT NULL AND NEW.arbol_origen_id = NEW.id THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Un árbol no puede ser su propio origen';
    END IF;
END;

